$(function renderGraph() {

  var margin = {
    top: 20,
    right: 20,
    bottom: 30,
    left: 40
  };
  w = 700;
  h = 300;
  var dateArr = [];
  var tweetArr = [];

  getIntervalType = function (el) {
    var dataInterval;
    dataInterval = $(el).data("interval");
    if (dataInterval == "minutes") {
      setMinuteInterval();
      minuteTimeout();
    } else if (dataInterval == "hours") {
      setHourInterval();
      hourTimeout();
    } else if (dataInterval == "days") {
      setDayInterval();
      dayTimeout();
    }
  };

  x = d3.time.scale().range([0, w]);
  y = d3.scale.linear().range([h, 0]);

  xAxis = d3.svg.axis().scale(x).orient('bottom').ticks(8);
  yAxis = d3.svg.axis().scale(y).orient('left').tickSize(-w).ticks(5);

  var drawGraph = function(d) {

    dateArr.sort(function(a,b) {
      a = new Date(a);
      b = new Date(b);
      return a<b?-1:a>b?1:0;
    });

    d.sort(function(a,b) {
      a = new Date(a.date);
      b = new Date(b.date);
      return a<b?-1:a>b?1:0;
    });

    x.domain([dateArr[0], dateArr[dateArr.length - 1]]);
    y.domain([0, 5 * Math.ceil(d3.max(tweetArr) / 5)]);

    var svg = d3.select("#chart").append("svg")
        .data([d])
        .attr("style", "margin: 20px auto")
        .attr("width", w + 100)
        .attr("height", h + 100)
      .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    var tooltip = d3.select("#chart").append("div")
      .data([d])
      .style("position", "absolute")
      .style("z-index", "10")
      .style("opacity", 0)
      .attr("class", "d3tooltip")
      .text(function(d){ return d.date + d.tweet_count; })

    var line = d3.svg.line()
      .interpolate("monotone")
      .x(function(d) { return x(new Date(d.date)); })
      .y(function(d) { return y(d.tweet_count); })

    svg.append("g")
        .attr("class", "xAxis")
        .attr("transform", "translate(0," + h + ")")
        .call(xAxis);

    svg.append("g")
        .attr("class", "yAxis")
        .call(yAxis);

    var path = svg.append("svg:path")
        .attr("class", "line")
        .attr("d", line);


    svg.selectAll('.point')
      .data(d)
    .enter().append("circle")
      .attr("class", "point")
      .attr("r", 2)
      .attr("cx", function(d){ return x(new Date(d.date)) })
      .attr("cy", function(d){ return y(d.tweet_count) })
      .on('click', function(d, i){ return console.log(d, i) })
      .on("mouseover", function(d) {
        d3.select(this).attr('r', 8);
        tooltip.transition()
          .duration(200)
          .style("opacity", 0.9);
        tooltip.html(new Date(d.date) + "<br/>" + d.tweet_count + " tweets")
      })
      .on("mousemove", function(){ return tooltip.style("top", (event.pageY-10)+"px").style("left",(event.pageX+10)+"px"); })
      .on("mouseout", function() {
        d3.select(this).attr('r', 2)
        tooltip.transition()
          .duration(200)
          .style("opacity", 0);
      });

  };

  var setMinuteInterval = function() {
    d3.json("http://dev.odimax.com/get_graphdata_minute.php", function(error, data) {
      type(data);
      drawGraph(data);
    });
  }

  var setHourInterval = function() {
    d3.json("http://dev.odimax.com/get_graphdata_hour.php", function(error, data) {
      type(data);
      drawGraph(data);
    });
  }

  var setDayInterval = function() {
    d3.json("http://dev.odimax.com/get_graphdata_day.php", function(error, data) {
      type(data);
      drawGraph(data);
    });
  }

  var minuteTimeout = function() {
    var minuteInterval = setTimeout(function() {
      $("#chart").empty();
      setMinuteInterval();
    }, 10000);
  }
  var hourTimeout = function() {
    var hourInterval = setTimeout(function() {
      $("#chart").empty();
      setHourInterval();
    }, 10000);
  }
  var dayTimeout = function() {
    var dayInterval = setTimeout(function() {
      $("#chart").empty();
      setDayInterval();
    }, 10000);
  }

  function type(d) {

    for (var i=0; i<d.length; i++) {
      date = new Date(d[i].date);
      filledDateArr = dateArr.push(date);
      tweets = d[i].tweet_count;
      parsedTweets = parseInt(tweets, 10);
      filledTweetArr = tweetArr.push(parsedTweets, 10);
    }
    return d;
  }

  intervalType = getIntervalType($("li.active"));

  $("li").on("click", resetGraph);

  function resetGraph() {
    dateArr.length = 0;
    tweetArr.length = 0;
    $("#chart").empty();
    intervalType = getIntervalType(this);
  };

  var getIntervalTimeout = setTimeout(function() {
    getIntervalType(intervalType);
  }, 10000);

  if (intervalType == "minutes") {
//    setMinuteInterval();
    minuteTimeout();
  } else if (intervalType == "hours") {
//    setHourInterval();
    hourTimeout();
  } else if (intervalType == "days") {
//    setDayInterval();
    dayTimeout();
  }
});
//      var currentTime, data, getIntervalType, h, intervalType, margin, max, renderGraph, startTimeDay, startTimeHour, startTimeMonth, theDate, w;
//      data = [3, 7, 9, 1, 4, 6, 8, 2, 5];
//      margin = {
//        top: 20,
//        right: 20,
//        bottom: 30,
//        left: 40
//      };
//      w = 700;
//      h = 300;
//      max = d3.max(data);
//      theDate = new Date();
//      startTimeHour = d3.time.hour.offset(theDate, -2);
//      startTimeDay = d3.time.hour.offset(theDate, -24);
//      startTimeMonth = d3.time.month.offset(theDate, -1);
//      currentTime = new Date();
//      getIntervalType = function(el) {
//        var dataInterval;
//        dataInterval = $(el).data("interval").type;
//        if (dataInterval === 'hours') {
//          return startTimeHour;
//        } else if (dataInterval === 'days') {
//          return startTimeDay;
//        } else if (dataInterval === 'months') {
//          return startTimeMonth;
//        }
//      };
//      renderGraph = function(int) {
//        var svg, x, x2, xAxis, y, yAxis;
//        x = d3.scale.linear().domain([0, data.length - 1]).range([0, w]);
//        x2 = d3.time.scale().domain([int, currentTime]).range([0, w]);
//        y = d3.scale.linear().domain([0, max + 1]).range([h, 0]);
//        xAxis = d3.svg.axis().scale(x2).orient('bottom').ticks(6);
//        yAxis = d3.svg.axis().scale(y).orient('left').ticks(10);
//        svg = d3.select('#chart').attr("style", "margin: 20px auto").append('svg').attr('width', w + 100).attr('height', h + 100).append("g")
//          .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
//        svg.append("g").attr("class", "xAxis").attr("transform", "translate(0," + h + ")").call(xAxis).selectAll("text").style("text-anchor", "start");
//        svg.append("g").attr("class", "yAxis").call(yAxis);
//        return svg.selectAll('path.line').data([data]).enter().append("svg:path").attr("class", "dataLine").attr("d", d3.svg.line().interpolate("cardinal").x(function(d, i) {
//          return x(i);
//        }).y(y));
//      };
//      intervalType = getIntervalType($("li.active"));
//      renderGraph(intervalType);
//      return $("li").on("click", function() {
//        $("#chart").empty();
//        intervalType = getIntervalType(this);
//        return renderGraph(intervalType);
//      });

